cycle time: 18
FPU Single: Y
FPU Double: Y